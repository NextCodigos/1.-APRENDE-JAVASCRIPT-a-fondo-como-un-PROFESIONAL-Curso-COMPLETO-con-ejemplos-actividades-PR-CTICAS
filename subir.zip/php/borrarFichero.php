<?php
    // Escribir el código PHP

?>