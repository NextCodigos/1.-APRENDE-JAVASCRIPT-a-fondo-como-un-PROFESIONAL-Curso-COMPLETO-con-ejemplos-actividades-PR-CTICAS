<?php
    $servername="localhost";
    $username= "root";
    $password = "";
    // Modificar "albumes" por el nombre de la bae de datos que hayas creado
    $database = "albumes";
    // Escribir el resto del código PHP
?>